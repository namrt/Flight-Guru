# Birds

This is the frontend layer to the Advanced DBMS project, made using the AngularJS web framework.

# Motivation

The project aims at creating a system that would help the customer with their travel
plans. As we know, flight delays can result in disruption of someone’s travel plan.
The system that we plan on designing and implementing will aid the customer by
suggesting the flights with minimum chances of delay based on the past data. Also,
it will suggest the best destination to visit during a particular time of the year and the
best flights to take for it.

# Installation

Be sure to have NPM and Node installed on your system.
In the project directory, execute 'npm install' followed by 'npm start'.
