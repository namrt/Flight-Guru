import {Component, Input, OnInit} from '@angular/core';
import {Airport} from "../models/Airport";
import {AirportsService} from "../services/airports.service";
import {NgxUiLoaderService, SPINNER} from "ngx-ui-loader";
import {ActivatedRoute} from "@angular/router";
import {DestinationsService} from "../services/destinations.service";
import {Destination} from "../models/Destination";

@Component({
  selector: 'best-destinations',
  templateUrl: './best-destinations.component.html',
  styleUrls: ['./best-destinations.component.css']
})
export class BestDestinationsComponent implements OnInit {
  @Input() from: string;
  @Input() to: string;
  @Input() departureDate: Date;
  @Input() returnDate: Date;
  public airports: Airport[];

  // options for the chart
  view: any[] = [600, 400];
  showXAxis = true;
  showYAxis = true;
  gradient = false;
  showLegend = true;
  showXAxisLabel = true;
  xAxisLabel = 'Country';
  showYAxisLabel = true;
  yAxisLabel = 'Sales';
  timeline = true;
  colorScheme = {
    domain: ['#9370DB', '#87CEFA', '#FA8072', '#FF7F50', '#90EE90', '#9370DB']
  };

  public single;
  public SPINNER = SPINNER;
  public spinnerMessage = "Figuring out the best Destinations ...";

  constructor(private airportsService: AirportsService,
              private destinationsService: DestinationsService,
              private route: ActivatedRoute,
              private ngxService: NgxUiLoaderService) { }

  ngOnInit() {
    this.setAirportsAndBestDestinations();
  }

  setAirportsAndBestDestinations(): void {
    this.ngxService.start();
    this.airportsService.getAllAirports().subscribe(airports => {
      this.airports = airports;
      this.destinationsService.getBestDestinations().subscribe((destinations: Destination[]) => {
        this.single = [];
        destinations.forEach(destination => {
          this.single.push({
            "name" : destination.DEST,
            "value" : destination.No_of_Flights
          });
        });
        this.ngxService.stop();
      });
    });
  }
}
