import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserFlightSearchInputsComponent } from './user-flight-search-inputs/user-flight-search-inputs.component';
import {ReactiveFormsModule} from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BsDropdownModule } from 'ngx-bootstrap';
import { BestFlightsComponent } from './best-flights/best-flights.component';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { BestDestinationsComponent } from './best-destinations/best-destinations.component';
import { HttpClientModule } from '@angular/common/http';
import {RouterModule} from '@angular/router';
import {NgxUiLoaderModule} from 'ngx-ui-loader';
import { ResultsPageComponent } from './results-page/results-page.component';

@NgModule({
  declarations: [
    AppComponent,
    UserFlightSearchInputsComponent,
    BestFlightsComponent,
    BestDestinationsComponent,
    ResultsPageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    BsDropdownModule.forRoot(),
    BsDatepickerModule.forRoot(),
    NgxChartsModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: '', component: UserFlightSearchInputsComponent},
      { path: 'results', component: ResultsPageComponent}
    ]),
    NgxUiLoaderModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
