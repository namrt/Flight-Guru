import { Injectable } from '@angular/core';
import {environment} from '../../environments/environment';
import {HttpClient, HttpErrorResponse} from '@angular/common/http';
import {catchError, map} from 'rxjs/operators';
import {Observable, throwError} from 'rxjs';
import {Airport} from "../models/Airport";

@Injectable({
  providedIn: 'root'
})
export class AirportsService {
  baseUrl = environment.flightsApiBaseUrl;

  constructor(private http: HttpClient) { }

  getAllAirports(): Observable<Airport[]>  {
    return this.http.get<Airport[]>(this.baseUrl + '/getAllAirports').pipe(
      map((response: Airport[]) => {
        return response.map((airport: Airport) => {
          airport.displayValue = airport.Code + ' - ' + airport.Name;
          return airport;
        });
      }),
      catchError(this.handleError)
    );
  }

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      console.error('An error occurred:', error.error.message);
    } else {
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    return throwError('Something bad happened; please try again later.');
  }
}
