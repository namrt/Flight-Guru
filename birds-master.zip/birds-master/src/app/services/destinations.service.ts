import { Injectable } from '@angular/core';
import {environment} from "../../environments/environment";
import {HttpClient, HttpErrorResponse} from "@angular/common/http";
import {Observable, throwError} from "rxjs";
import {catchError} from "rxjs/operators";
import {Destination} from "../models/Destination";

@Injectable({
  providedIn: 'root'
})
export class DestinationsService {
  baseUrl = environment.destinationsApiBaseUrl;

  constructor(private http: HttpClient) { }

  getBestDestinations(): Observable<Destination[]> {
    return this.http.get<Destination[]>(this.baseUrl + '/getBestDestinations').pipe(
      catchError(this.handleError)
    );
  }

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      console.error('An error occurred:', error.error.message);
    } else {
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    return throwError('Something bad happened; please try again later.');
  }
}
