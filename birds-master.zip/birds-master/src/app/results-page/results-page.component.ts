import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from "@angular/router";

@Component({
  selector: 'app-results-page',
  templateUrl: './results-page.component.html',
  styleUrls: ['./results-page.component.css']
})
export class ResultsPageComponent implements OnInit {
  public from: string;
  public to: string;
  public departureDate: Date;
  public returnDate: Date;

  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    this.from = this.route.snapshot.queryParamMap.get('from');
    this.to = this.route.snapshot.queryParamMap.get('to');
    this.departureDate = new Date(this.route.snapshot.queryParamMap.get('departureDate'));
    this.returnDate = new Date(this.route.snapshot.queryParamMap.get('returnDate'));
  }
}
