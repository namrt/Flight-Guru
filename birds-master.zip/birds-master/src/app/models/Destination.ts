export class Destination {
  DEST: string;
  Month: number;
  No_of_Flights: number;
  ORIGIN: string;
}

