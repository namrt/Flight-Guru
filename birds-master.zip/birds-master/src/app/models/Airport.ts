export class Airport {
  Code: number;
  Name: string;
  displayValue: string;
}
