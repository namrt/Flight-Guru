export class Flight {
  DEST: number;
  OP_CARRIER: string;
  ORIGIN: string;
  TOTAL_AV_DELAY: number;
}
