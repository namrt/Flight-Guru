import { Component, OnInit } from '@angular/core';
import {FormBuilder, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import {AirportsService} from '../services/airports.service';
import {NgxUiLoaderService, SPINNER} from 'ngx-ui-loader';
import {Airport} from "../models/Airport";

@Component({
  selector: 'user-flight-search-inputs',
  templateUrl: './user-flight-search-inputs.component.html',
  styleUrls: ['./user-flight-search-inputs.component.css']
})
export class UserFlightSearchInputsComponent implements OnInit {
  userFlightSearchForm = this.fb.group({
    from: ['', Validators.required],
    to: ['', Validators.required],
    departureDate: ['', Validators.required],
    returnDate: ['', Validators.required]
  });

  public airports: Airport[];
  public SPINNER = SPINNER;
  public spinnerMessage = "Get Ready To Fly!";

  constructor(private fb: FormBuilder, private router: Router,
              private airportsService: AirportsService,
              private ngxService: NgxUiLoaderService) { }

  ngOnInit() {
    this.setAirportsList();
  }

  showResults() {
     this.router.navigate(["/results"], {queryParams: {
         from: this.userFlightSearchForm.get('from').value,
         to: this.userFlightSearchForm.get('to').value,
         departureDate: this.userFlightSearchForm.get('departureDate').value,
         returnDate: this.userFlightSearchForm.get('returnDate').value
     }});
  }

  setAirportsList(): void {
    this.ngxService.start();
    this.airportsService.getAllAirports().subscribe(airports => {
      this.airports = airports;
      this.ngxService.stop();
    });
  }
}
