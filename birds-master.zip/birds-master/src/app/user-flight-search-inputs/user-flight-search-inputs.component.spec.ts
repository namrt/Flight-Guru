import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserFlightSearchInputsComponent } from './user-flight-search-inputs.component';

describe('UserFlightSearchInputsComponent', () => {
  let component: UserFlightSearchInputsComponent;
  let fixture: ComponentFixture<UserFlightSearchInputsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserFlightSearchInputsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserFlightSearchInputsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
