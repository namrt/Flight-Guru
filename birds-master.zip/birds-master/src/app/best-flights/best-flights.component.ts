import {Component, Input, OnInit} from '@angular/core';
import {FlightsService} from '../services/flights.service';
import {ActivatedRoute} from '@angular/router';
import {NgxUiLoaderService, SPINNER} from "ngx-ui-loader";

@Component({
  selector: 'best-flights',
  templateUrl: './best-flights.component.html',
  styleUrls: ['./best-flights.component.css']
})
export class BestFlightsComponent implements OnInit {
  @Input() from: string;
  @Input() to: string;
  @Input() departureDate: Date;
  @Input() returnDate: Date;

  // options for the chart
  view: any[] = [600, 400];
  showXAxis = true;
  showYAxis = true;
  gradient = false;
  showLegend = true;
  showXAxisLabel = true;
  xAxisLabel = 'Country';
  showYAxisLabel = true;
  yAxisLabel = 'Sales';
  timeline = true;
  colorScheme = {
    domain: ['#9370DB', '#87CEFA', '#FA8072', '#FF7F50', '#90EE90', '#9370DB']
  };

  public single;
  public SPINNER = SPINNER;
  public spinnerMessage = "Figuring out the best flights ...";

  constructor(private flightsService: FlightsService,
              private route: ActivatedRoute,
              private ngxService: NgxUiLoaderService) { }

  ngOnInit() {
    this.setBestFlights();
  }

  setBestFlights(): void {
    this.ngxService.start();
    this.flightsService.getBestFlights()
      .subscribe(bestFlights => {
        this.single = [];
        bestFlights.forEach(flight => {
          this.single.push({
            "name" : flight.OP_CARRIER,
            "value" : flight.TOTAL_AV_DELAY
          });
        });
        this.ngxService.stop();
      });
  }
}
